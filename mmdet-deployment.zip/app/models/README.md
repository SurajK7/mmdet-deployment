place holder READEME.md for models directory

Ideally after running python server.py or python server.py serve first time, you will have a model.pth file in this directory. 
